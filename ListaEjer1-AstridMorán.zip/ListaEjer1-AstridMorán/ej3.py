#.Ingrese 3 valores y realice las operaciones de suma ,resta y multiplicación.


a=int(input('Ingresar valor 1: '))
b=int(input('Ingresar valor 2: '))
c=int(input('Ingresar valor 3: '))

##suma
suma= a+b+c

##resta
resta=a-b-c

##multiplicacion
multi=a*b*c

print(f" La suma es: {suma}\n La resta es: {resta}\n La multiplicación es: {multi}")
