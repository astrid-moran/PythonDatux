#Ingrese un valor e imprima el tipo de dato.


a=input("Ingrese cualquier valor: ")

print(type(a))
