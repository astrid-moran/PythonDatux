#Realice un programa que imprima la ubicación de su carpeta donde se encuentra
#trabajando.
import sys
variable=sys.argv[0]
print('La carpeta donde se encuentra trabajando es:')
print(variable)