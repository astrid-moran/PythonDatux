#Calcule el área de un círculo con radio ingresado desde el teclado.
import numpy as np
r=int(input("Ingresar radio del circulo deseado= "))
area=(np.pi)*(r**2)
print(f'El valor del area es {area}')
